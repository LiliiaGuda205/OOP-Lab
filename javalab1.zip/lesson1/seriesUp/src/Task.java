public class Task {

    // Дано число n >=0. Метод возвращает массив по шаблону
    // {1, 1,2, 1,2,3,  ...1,2,3..n}
    // Например
    // seriesUp(3) → [1, 1, 2, 1, 2, 3]
    // seriesUp(4) → [1, 1, 2, 1, 2, 3, 1, 2, 3, 4]
    // seriesUp(2) → [1, 1, 2]
    //
    // Длина итогового массива = n*(n+1)/2
    public int[] seriesUp(int n) {
        int[] result = new int[n * (n + 1) / 2];
        int index = 0;
        int locallimit = 1;
        while (index < result.length){
            for (int i = 1; i < locallimit + 1; i++){
                result[index] = i;
                index++;
            }
            locallimit++;
        }
        return result;
    }

}