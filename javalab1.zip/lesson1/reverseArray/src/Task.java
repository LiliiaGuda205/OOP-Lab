public class Task {

    // Метод выводит массив в обратном порядке
    public int[] reverseArray(int[] array) {

        int [] result = new int [array.length];
        for (int i = 0; i < array.length; i++) {
            result[array.length - i - 1] = array[i];

        }
        return result;
    }
}