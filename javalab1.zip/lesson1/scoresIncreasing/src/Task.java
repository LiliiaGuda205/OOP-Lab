public class Task {

    // Дан массив, метод возвращает true если каждый элемент массива равен или больше предыдущему
    public boolean scoresIncreasing(int[] a) {

        for (int i = 1; i < a.length; i++){
            if (a[i-1] > a[i])
                return false;
        }
        return true;
    }

}