public class Task {

    // Метод выводит массив, сумма элементов которого больше. Если массивы равны - выводим а
    public int[] biggestArray(int[] a, int[] b) {


        int SumA = 0;
        for (int i : a)
            SumA += i;
        
        int SumB = 0;
        for (int i : b)
            SumB += i;
        
        if (SumA >=SumB)
            return a;
        else
            
        return b;
    }
}