public class Task {

    public boolean sleepIn(boolean weekday, boolean vacation) {


        if (!weekday || vacation)
        {
            return true;
        } else {
                return false;
            }
            }
        }

