public class Task {

    // Дан непустой массив. Метод возвращает true, если массив можно разбить на две части
    // (необязательно равные) таким образом, чтобы сумма частей была равна.
    // canSplit([1, 1, 1, 2, 1]) → true ([1,1,1] [2,1])
    // canSplit([2, 1, 1, 2, 1]) → false
    // canSplit([10, 1, 2, 3, 4]) → true ([10] [1,2,3,4])
    public boolean canSplit(int[] a) {

       int Sum1 = 0;
       for (int i = 0; i < a.length - 1; i++){
           Sum1 = Sum1 + a[i];

           int Sum2 = 0;
           for (int j = i + 1; j< a.length; j++) {
               Sum2 = Sum2 + a[j];

           }
           if (Sum1 == Sum2)
               return true;
       }
        return false;
    }

}